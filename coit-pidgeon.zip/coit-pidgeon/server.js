const express = require("express");
const exphbs  = require("express-handlebars");
const app = express();
var hbs = exphbs.create({});
app.use(express.static("public"));
app.use(function(err, req, res, next){
    res.status(422).send({error: err.message});
});
app.use(function(err, req, res, next){
    res.status(404).send({error: err.message});
});
app.engine("handlebars", hbs.engine);
app.set("view engine", "handlebars");
app.locals.layout = false
app.use("/api", require("./routes/api"));
app.use("/",    require("./routes/index"));
app.listen(process.env.port||4000,function(){console.log("Now listening on 4000");});