const express           = require("express");
const router            = express.Router();
const axios             = require("axios");

router.get('/grafana/:query', function(req, res, next){
    var query = req.params.query;
    var url = 'https://grafana.ccit.ops.charter.com/api/search?query='+query
    axios.get(url,config).then(response => {
        res.json(response.data);
    })
});

router.get('/grafana/datasources/:query', function(req, res){
    var query = req.params.query;
    var url = 'https://grafana.ccit.ops.charter.com/api/datasources/'
    axios.get(url,config).then((response) => {
        res.json(response.data);
    })
});

module.exports = router;